import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Campuses from '../components/Campuses.vue'
import Careers from '../components/Careers.vue'
import CareersStudents from '../components/CareersStudents.vue'

Vue.use(VueRouter)

const routes = [
  { path: '/', name: 'home', component: Home },
  { path: '/campuses', name: 'campuses', component: Campuses },
  { path: '/careers', name: 'careers', component: Careers, 
    children: [
      { path: ':id/students', name: 'careersstudents', component: CareersStudents }
    ]
  },
  { path: '/about', name: 'about',
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
