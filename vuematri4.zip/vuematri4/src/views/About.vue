<template>
  <div class="about">
    <h1>Proyecto elaborado por:</h1>
      
  </div>
</template>
