<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <h1>Proyecto elaborado en vue.js</h1>
  </div>
</template>

<script>
export default {
  name: 'home',

}
</script>
