<template>
	<v-card class="mx-auto mb-5" max-width="800" >
    <v-card-text >
      <v-data-table :headers="headersStudents" :items="dessertsStudents" :search="searchText" 
        sort-by="id" :items-per-page="3" class="elevation-1" >
        <template v-slot:top>
          <v-toolbar flat color="white">
            <v-toolbar-title>Students of {{ carreraItem.name }} </v-toolbar-title>
            <v-divider class="mx-4" inset vertical ></v-divider>
            <v-spacer></v-spacer>
            <v-text-field class="text-xs-center" v-model="searchText" append-icon="search" 
            label="Search text" single-line hide-details > </v-text-field>
            <v-spacer></v-spacer>
            
            <v-dialog v-model="dialogEdit" max-width="500px">
              <template v-slot:activator="{ on }">
                <v-btn color="primary" dark class="mb-2" v-on="on">New Student</v-btn>
              </template>
              <v-card>
                <v-card-title>
                <span class="headline">{{ formTitle }}</span>
                </v-card-title>
            
                <v-card-text>
                  <v-container>
                    <v-row>		
                    <v-col cols="12" sm="6" md="2">
                      <v-text-field v-model="editedItem.id" label="Student Id" readonly></v-text-field>
                    </v-col>									
                    <v-col cols="12" sm="6" md="7">
                      <v-text-field v-model="editedItem.lastName" label="Last name"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="7">
                      <v-text-field v-model="editedItem.firstMidName" label="First name"></v-text-field>
                    </v-col>
                    </v-row>
                  </v-container>
                </v-card-text>
            
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="close">Cancel</v-btn>
                  <v-btn color="green darken-1" text @click="saveItem">Save</v-btn>
                  <v-spacer></v-spacer>
                </v-card-actions>
              </v-card>
            </v-dialog>

            <v-dialog v-model="dialogConfirm" max-width="290">
              <v-card>
                <v-card-title class="headline">Delete Student?</v-card-title>
                <v-card-text>
                Would you like to delete this Student?
                {{deletedItem.id}} - {{deletedItem.lastName}} {{deletedItem.firstMidName}}
                </v-card-text>
                <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn color="green darken-1" text @click="dialogConfirm = false"> Cancel </v-btn>
                <v-btn color="red darken-1" text @click="confimDelete()" > Delete </v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog>

          </v-toolbar>
        </template>

        <template v-slot:item.action="{ item }">
          <v-icon color="blue" class="mr-2" @click="editItem(item)" > edit </v-icon>
          <v-icon color="red" @click="deleteItem(item)" > delete </v-icon>    
        </template>
        <template v-slot:no-data>
          <v-btn color="primary" @click="initialize">Reset</v-btn>
        </template>

      </v-data-table>
    </v-card-text>
    <v-card-actions>
      <v-spacer></v-spacer>
      <v-btn color="blue darken-1" text :to="{name: 'careers'}">Close</v-btn>
      <v-spacer></v-spacer>
    </v-card-actions>
	</v-card>  

</template>

<script>
  import axios from "axios";
  export default {
    data: () => ({
		careerID: 0,
		dialogEdit: false,
		dialogConfirm: false,
		headersStudents: [			
			{ text: 'Id', align: 'left', sortable: false, value: 'id' },
			{ text: 'Last Name', value: 'lastName' },
			{ text: 'First Middle Name', value: 'firstMidName' },
			{ text: 'Career Id', value: 'careerID' },
			{ text: 'Actions', value: 'action', sortable: false },
		],
		dessertsStudents: [],
		searchText: '',
		errors: [],
		editedIndex: -1,
		deletedIndex: -1,
		carreraItem: { careerID: 0, name: ''},
		newItem: { lastName: '', firstMidName: '', careerID: 0 },
		editedItem: {id: 0, lastName: '', firstMidName: '', careerID: 0},
		deletedItem: {id: 0, lastName: '', firstMidName: '', careerID: 0},
		responseItem: {id: 0, lastName: '', firstMidName: '', careerID: 0},
		defaultItem: {id: 0, lastName: '', firstMidName: '', careerID: 0},		
		responseStatus: 0,
  	}),
	created () {
		this.initialize()
	},
  	computed: {
    	formTitle () {
      		return this.editedIndex === -1 ? 'New Student' : 'Edit Student'
    	},
  	},

  	watch: {
    	dialog (val) {
      		val || this.close()
		},
		$route(to, from) {
			this.reload();
		},
		responseItem() {
			this.pushResponse();
		}
  	},

	methods: {
		initialize () {			
			this.careerID = Number(this.$route.params.id);
			this.getCarrera();
			this.getStudents();
		},
		reload() {
			this.careerID = Number(this.$route.params.id);
			this.getCarrera();
			this.getStudents();
		},
		pushResponse() {
			if (this.responseStatus == 200 || this.responseStatus == 201) {
				this.responseStatus = 0;
				this.dessertsStudents.push(this.responseItem);
			}			
		},
		editItem (item) {
			this.editedIndex = this.dessertsStudents.indexOf(item)
			this.editedItem = Object.assign({}, item)
			this.dialogEdit = true
		},
		deleteItem (item) {
			this.deletedIndex = this.dessertsStudents.indexOf(item)
			this.deletedItem = Object.assign({}, item)
			this.dialogConfirm = true
		},
		confimDelete () {
			this.deleteStudent( this.deletedItem.id )
			this.dessertsStudents.splice(this.deletedIndex, 1)
			this.dialogConfirm = false
		},
		close () {
			this.dialogEdit = false
			setTimeout(() => {
				this.editedItem = Object.assign({}, this.defaultItem)
				this.editedIndex = -1
			}, 300)
		},
		saveItem () {
			// Edición
			if (this.editedIndex > -1) {
				this.putStudent( this.editedItem );
				Object.assign(this.dessertsStudents[this.editedIndex], this.editedItem)
			} else {
				// Nuevo { lastName: '', firstMidName: '', careerID: 0 },
				this.newItem.lastName = this.editedItem.lastName;
				this.newItem.firstMidName = this.editedItem.firstMidName;
				this.newItem.careerID = this.careerID;
				// -
				this.postStudent(this.newItem)
			}
			this.close()
		},
		// Consume REST API
		getCarrera() {
			axios.get("https://localhost:5001/api/Careers/" + this.careerID)
				.then( response => {
					this.carreraItem = response.data;
				})
				.catch( error => {
					this.errors.push(error)
				})
		},
		getStudents() {
			axios.get("https://localhost:5001/api/Careers/" + this.careerID + "/Students")
				.then( response => {
					this.dessertsStudents = response.data;					
				})
				.catch( error => {
					this.errors.push(error)
				})
		},
		postStudent(student) {
			axios.post('https://localhost:5001/api/Careers/' + this.careerID + '/Student', student)
				.then( response => {
					this.responseItem = response.data;
					this.responseStatus = response.status;
				})
				.catch( error => {
					console.log(error);
					this.errors.push(error)
				});
		},
		putStudent(student) {
			// Como no esta implementado se utiliza el PUT de StudentApi
			axios.put('https://localhost:5001/api/Students/' + student.id, student)
				.then( response => { })
				.catch( error => {
					this.errors.push(error)
				});
		},
		deleteStudent(id) {
			// Como no esta implementado se utiliza el PUT de StudentApi
			axios.delete('https://localhost:5001/api/Students/' + id)
				.then( response => { 
					this.responseItem = response.data;
				})
				.catch( error => {
					this.errors.push(error)
				});
		},

	},
}
</script>

<style>

</style>