<template>
<v-container grid-list-md text-md-center fluid fill-height>
    <v-layout  align-start>
        <v-flex >
            <v-data-table :headers="headers" :items="desserts" :search="searchText" 
					sort-by="campusID" class="elevation-1" >
				<template v-slot:top>
					<v-toolbar flat color="white">
						<v-toolbar-title>Campuses</v-toolbar-title>
						<v-divider class="mx-4" inset vertical ></v-divider>
						<v-spacer></v-spacer>
						<v-text-field class="text-xs-center" v-model="searchText" append-icon="search" 
							label="Search text" single-line hide-details > </v-text-field>
						<v-spacer></v-spacer>
						
						<v-dialog v-model="dialog" max-width="500px">
							<template v-slot:activator="{ on }">
								<v-btn color="primary" dark class="mb-2" v-on="on">New Campus</v-btn>
							</template>
							<v-card>
								<v-card-title>
									<span class="headline">{{ formTitle }}</span>
								</v-card-title>
					
								<v-card-text>
									<v-container>
										<v-row>		
											<v-col cols="12" sm="6" md="4">
												<v-text-field v-model="editedItem.campusID" label="Campus Id" readonly></v-text-field>
											</v-col>									
											<v-col cols="12" sm="6" md="4">
												<v-text-field v-model="editedItem.name" label="Campus Name"></v-text-field>
											</v-col>
										</v-row>
									</v-container>
								</v-card-text>
					
								<v-card-actions>
									<v-spacer></v-spacer>
									<v-btn color="blue darken-1" text @click="close">Cancel</v-btn>
									<v-btn color="green darken-1" text @click="save">Save</v-btn>
                                    <v-spacer></v-spacer>
								</v-card-actions>
							</v-card>
						</v-dialog>

						<v-dialog v-model="dialogConfirm" max-width="290">
							<v-card>
								<v-card-title class="headline">Delete Campus?</v-card-title>
								<v-card-text>
									Would you like to delete this campus?
									{{deletedItem.campusID}} - {{deletedItem.name}}
								</v-card-text>
								<v-card-actions>
									<v-spacer></v-spacer>
									<v-btn color="green darken-1" text @click="dialogConfirm = false"> Cancel </v-btn>
									<v-btn color="red darken-1" text @click="confimDelete()" > Delete </v-btn>
								</v-card-actions>
							</v-card>
						</v-dialog>

						<v-dialog v-model="dialogStudents" max-width="800px">
							<v-card>
								<v-card-title class="headline">Students de {{editedItem.name}}</v-card-title>
								<v-card-text>
									
									<template>
										<v-data-table
											:headers="headersStudents" :items="dessertsStudents" :items-per-page="5" class="elevation-1"
										></v-data-table>
									</template>

								</v-card-text>
								<v-card-actions>
									<v-spacer></v-spacer>
									<v-btn color="blue darken-1" text @click="dialogStudents = false">Close</v-btn>
								</v-card-actions>
							</v-card>
						</v-dialog>

					</v-toolbar>
				</template>

				<template v-slot:item.action="{ item }">
					<v-icon color="green" class="mr-2" @click="viewStudents(item)" > people_alt </v-icon>
					<v-icon color="blue" class="mr-2" @click="editItem(item)" > edit </v-icon>
					<v-icon color="red" @click="deleteItem(item)" > delete </v-icon>
				</template>
				<template v-slot:no-data>
					<v-btn color="primary" @click="initialize">Reset</v-btn>
				</template>
			</v-data-table>
          
        </v-flex>
    </v-layout>

</v-container>
</template>

<script>
import axios from "axios";
export default {
    data: () => ({
		dialog: false,
		dialogConfirm: false,
		dialogStudents: false,
    	headers: [
			{ text: 'Campus Id', align: 'left', sortable: false, value: 'campusID' },
			{ text: 'Campus Name', value: 'name' },
			{ text: 'Actions', value: 'action', sortable: false },
		],
		searchText: '',
		desserts: [],
		errors: [],
		editedIndex: -1,
		deletedIndex: -1,
		newItem: { name: '' },
		editedItem: { campusID: 0, name: '' },
		deletedItem: { campusID: 0, name: '' },
		responseItem: { campusID: 0, name: ''},
		defaultItem: { campusID: 0, name: '' },

		headersStudents: [			
			{ text: 'Id', align: 'left', sortable: false, value: 'id' },
			{ text: 'Last Name', value: 'lastName' },
			{ text: 'First Middle Name', value: 'firstMidName' },
			{ text: 'Career Id', value: 'careerID' },
		],
		dessertsStudents: [
			{id: 1, lastName: 'Flores Moroco', firstMidName: 'Juan Antonio', careerID: 1},
			{id: 2, lastName: 'Flores Moroco', firstMidName: 'Juan Antonio', careerID: 1},
			{id: 3, lastName: 'Flores Moroco', firstMidName: 'Juan Antonio', careerID: 2},
			{id: 4, lastName: 'Flores Moroco', firstMidName: 'Juan Antonio', careerID: 2},
		],
  	}),

  	computed: {
    	formTitle () {
      		return this.editedIndex === -1 ? 'New Campus' : 'Edit Campus'
    	},
  	},

  	watch: {
    	dialog (val) {
      		val || this.close()
    	},
  	},

	created () {
		this.initialize()
	},

	methods: {
		initialize () {
			this.getCampuses();
		},

		confimDelete () {
			this.deleteCampus( this.deletedItem.campusID )
			this.desserts.splice(this.deletedIndex, 1)
			this.dialogConfirm = false
		},
		editItem (item) {
			this.editedIndex = this.desserts.indexOf(item)
			this.editedItem = Object.assign({}, item)
			this.dialog = true
		},
		deleteItem (item) {
			this.deletedIndex = this.desserts.indexOf(item)
			this.deletedItem = Object.assign({}, item)
			this.dialogConfirm = true
		},
		viewStudents (item) {
			this.editedIndex = this.desserts.indexOf(item)
			this.editedItem = Object.assign({}, item)
			this.dialogStudents = true
		},

		close () {
			this.dialog = false
			setTimeout(() => {
				this.editedItem = Object.assign({}, this.defaultItem)
				this.editedIndex = -1
			}, 300)
		},

		save () {
			// Edición
			if (this.editedIndex > -1) {
				this.putCampus( this.editedItem );
				Object.assign(this.desserts[this.editedIndex], this.editedItem)
			} else {
				// Nuevo
				this.newItem.name = this.editedItem.name;
				// -
				this.postCampus(this.newItem)
				Object.assign( this.editedIndex, this.responseItem )
				this.getCampuses()
			}
			this.close()
		},

		getCampuses() {
			axios.get("https://localhost:5001/api/Campuses")
				.then( response => {
					this.desserts = response.data
				})
				.catch( error => {
					this.errors.push(error)
				})
		},
		postCampus(campus) {
			axios.post('https://localhost:5001/api/Campuses', campus)
				.then( response => {
					this.responseItem = response.data;
				})
				.catch( error => {
					this.errors.push(error)
				});
		},
		putCampus(campus) {
			axios.put('https://localhost:5001/api/Campuses/' + campus.campusID, campus)
				.then( response => { })
				.catch( error => {
					this.errors.push(error)
				});
		},
		deleteCampus(campusID) {
			axios.delete('https://localhost:5001/api/Campuses/' + campusID)
				.then( response => { 
					this.responseItem = response.data;
				})
				.catch( error => {
					this.errors.push(error)
				});
		}
	},
}
</script>