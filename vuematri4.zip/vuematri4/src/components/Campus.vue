<template>
    <v-layout align-start>
        <v-flex>
            <v-data-table :headers="headers" :items="desserts" :search="searchText" 
					sort-by="campusID" class="elevation-1" >
				<template v-slot:top>
					<v-toolbar flat color="white">
						<v-toolbar-title>Campuses</v-toolbar-title>
						<v-divider class="mx-4" inset vertical ></v-divider>
						<v-spacer></v-spacer>
						<v-text-field class="text-xs-center" v-model="searchText" append-icon="search" 
							label="Search text" single-line hide-details > </v-text-field>
						<v-spacer></v-spacer>
						
						<v-dialog v-model="dialog" max-width="500px">
							<template v-slot:activator="{ on }">
								<v-btn color="primary" dark class="mb-2" v-on="on">New Campus</v-btn>
							</template>
							<v-card>
								<v-card-title>
									<span class="headline">{{ formTitle }}</span>
								</v-card-title>
					
								<v-card-text>
									<v-container>
										<v-row>		
											<v-col cols="12" sm="6" md="4">
												<v-text-field v-model="editedItem.campusID" label="Campus Id"></v-text-field>
											</v-col>									
											<v-col cols="12" sm="6" md="4">
												<v-text-field v-model="editedItem.name" label="Campus Name"></v-text-field>
											</v-col>
										</v-row>
									</v-container>
								</v-card-text>
					
								<v-card-actions>
									<v-spacer></v-spacer>
									<v-btn color="blue darken-1" text @click="close">Cancel</v-btn>
									<v-btn color="blue darken-1" text @click="save">Save</v-btn>
								</v-card-actions>
							</v-card>
						</v-dialog>

					</v-toolbar>
				</template>

				<template v-slot:item.action="{ item }">
					<v-icon small class="mr-2" @click="editItem(item)" > edit </v-icon>
					<v-icon small @click="deleteItem(item)" > delete </v-icon>
				</template>
				<template v-slot:no-data>
					<v-btn color="primary" @click="initialize">Reset</v-btn>
				</template>
			</v-data-table>
          
        </v-flex>
    </v-layout>


</template>

<script>
import axios from "axios";
export default {
    data: () => ({
    	dialog: false,
    	headers: [
			{ text: 'Campus Id', align: 'left', sortable: false, value: 'campusID' },
			{ text: 'Campus Name', value: 'name' },
			{ text: 'Actions', value: 'action', sortable: false },
		],
		searchText: '',
		desserts: [],
		errors: [],
		editedIndex: -1,
		newItem: { name: '' },
		editedItem: { campusID: 0, name: '' },
		responseItem: { campusID: 0, name: '' },
    	defaultItem: { campusID: 0, name: '' },
  	}),

  	computed: {
    	formTitle () {
      		return this.editedIndex === -1 ? 'New Campus' : 'Edit Campus'
    	},
  	},

  	watch: {
    	dialog (val) {
      		val || this.close()
    	},
  	},

	created () {
		this.initialize()
	},

	methods: {
		initialize () {
			this.getCampuses();
		},

		editItem (item) {
			this.editedIndex = this.desserts.indexOf(item)
			this.editedItem = Object.assign({}, item)
			this.dialog = true
		},

		deleteItem (item) {
			const index = this.desserts.indexOf(item)
			confirm('Are you sure you want to delete this item?') && this.desserts.splice(index, 1)
		},

		close () {
			this.dialog = false
			setTimeout(() => {
				this.editedItem = Object.assign({}, this.defaultItem)
				this.editedIndex = -1
			}, 300)
		},

		save () {
			// Edición
			if (this.editedIndex > -1) {
				this.putCampus( this.editedItem );
				Object.assign(this.desserts[this.editedIndex], this.editedItem)
			} else {
				// Nuevo
				this.newItem.name = this.editedItem.name;
				// -
				this.postCampus(this.newItem);
				this.getCampuses();
			}
			this.close()
		},

		getCampuses() {
			axios.get("https://localhost:5001/api/Campuses")
				.then(response => {
					this.desserts = response.data
				})
				.catch(e => {
					this.errors.push(e)
				})
		},
		postCampus(campus) {
			axios.post('https://localhost:5001/api/Campuses', campus)
			.then(function (response) {
				this.responseItem = response.data;
			})
			.catch(function (error) {
				this.output = error;
			});
		},
		putCampus(campus) {
			axios.post('https://localhost:5001/api/Campuses/' + campus.campusID, campus)
			.then(function (response) {
				this.responseItem = response.data;
			})
			.catch(function (error) {
				this.output = error;
			});
		}
	},
}
</script>